
DEMASK LOGO FULL PACK


**Logo Guidelines**

To ensure the logo remains clear and legible in all uses, 
there is to be clear space surrounding the logo that should be 
kept free of text and other elements. This area is to be equivalent 
to the full height and width of the logomark. Always use more where possible.

---------------------------------------------------------

**To maintain consistency in the logo usage, do not do any of the following with the logo**

‍1. Do not stretch, rotate, or distort the logo
2. Do not use unapproved colors
3. Do not decrease the opacity of the logo
4. Do not disassemble logo
5. Do not use text or image effects
6. Do not outline the logo

---------------------------------------------------------

**Thanks for reading**

